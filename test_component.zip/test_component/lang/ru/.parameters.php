<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS["EXAMPLE_COMPSIMPLE_PROP_SETTINGS"] = "Выбор Highblock";
$MESS["EXAMPLE_COMPSIMPLE_PROP_HIGHLOAD_TYPE"] = "Тип highload блока";
$MESS["EXAMPLE_COMPSIMPLE_PROP_ADDRESS"] = "Выводить все адреса или только активные";
