<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS["EXAMPLE_COMPSIMPLE_COMPONENT_PATH_ID"] = "local";
$MESS["EXAMPLE_COMPSIMPLE_COMPONENT_CHILD_PATH_ID"] = "darttestcomponentcustompath";
$MESS["EXAMPLE_COMPSIMPLE_COMPONENT_PATH_NAME"] = "Компонент тестовый";
$MESS["EXAMPLE_COMPSIMPLE"] = "Дочерняя ветка";
$MESS["EXAMPLE_COMPSIMPLE_COMPONENT"] = "Мой тестовый компонент";
$MESS["EXAMPLE_COMPSIMPLE_COMPONENT_DESCRIPTION"] = "Описание тестового компонента";